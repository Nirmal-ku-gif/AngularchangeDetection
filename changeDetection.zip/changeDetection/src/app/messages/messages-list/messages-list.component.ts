import { ChangeDetectionStrategy, ChangeDetectorRef, Component, DestroyRef, inject, input, OnInit } from '@angular/core';
import { MessagesService } from '../messages.service';
import { AsyncPipe } from '@angular/common';

@Component({
  selector: 'app-messages-list',
  standalone: true,
  imports:[AsyncPipe],
  templateUrl: './messages-list.component.html',
  styleUrl: './messages-list.component.css',
  changeDetection:ChangeDetectionStrategy.OnPush,  //change detection method
})
export class MessagesListComponent { //implements OnInit{
 private messagesService=inject(MessagesService);
//  private cdRef=inject(ChangeDetectorRef);   //manage change detection manuallyy
//  private destroryRef=inject(DestroyRef);
//  messages:string[]=[];
// ngOnInit(){
  // const subscription=this.messagesService.messages$.subscribe((message)=>{
  //   this.messages=message;
  //   this.cdRef.markForCheck();
  // });
  //   this.destroryRef.onDestroy(()=>{  // manually manage the subscription 
  //     subscription.unsubscribe();
  //   });

// }
messages$=this.messagesService.messages$;
  get debugOutput() {
    console.log('[MessagesList] "debugOutput" binding re-evaluated.');
    return 'MessagesList Component Debug Output';
  }
}
